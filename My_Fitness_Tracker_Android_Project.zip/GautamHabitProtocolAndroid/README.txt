MY FITNESS TRACKER — ANDROID PROJECT

This project builds the My Fitness Tracker Android app. It includes a custom black/neon-green launcher icon and matching in-app logo, plus the habit tracker web app packaged inside Android WebView.

BUILD USING YOUR EXISTING GITHUB ACTIONS WORKFLOW
1. In your GitHub repository, remove the old project ZIP so the workflow cannot select the wrong ZIP.
2. Upload this ZIP to the repository root.
3. Keep your existing Build apk.yml workflow that extracts the ZIP and runs Gradle with -p extracted/GautamHabitProtocolAndroid assembleDebug.
4. Open Actions, run the workflow, and download the APK artifact when the run succeeds.

The app display name is My Fitness Tracker. App check-ins remain stored locally in the app/WebView on the device.
